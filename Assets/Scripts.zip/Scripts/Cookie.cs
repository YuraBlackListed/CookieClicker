using UnityEngine;

namespace UI
{
    public class Cookie : MonoBehaviour
    {
        public int cookies = 1;
        [SerializeField] private SelfCount count;
        [SerializeField] private ToolAdder shop;
        public void AddCookie()
        {
            cookies++;
            count.SetCount(cookies);
        }
        public void RemoveCookies(int amount)
        {
            if(cookies >= amount)
            {
                shop.BuyTool(amount);
                cookies -= amount;
                count.SetCount(cookies);
            }
        }
    }
}
