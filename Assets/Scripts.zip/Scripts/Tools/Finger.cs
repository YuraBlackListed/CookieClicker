using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Finger : MonoBehaviour
{
    public GameManager manager;
    public void Click()
    {
        manager.AddCookie();
    }
}
