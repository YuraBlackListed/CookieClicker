using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public int cookies = 1;
    [SerializeField] private SelfCount count;
    [SerializeField] private ToolAdder shop;
    [SerializeField] private ParticleSystem particles;
    public void AddCookie()
    {
        cookies++;
        count.SetCount(cookies);
        var main = particles.main;
        main.maxParticles = cookies;
    }
    public void RemoveCookies(int amount)
    {
        if(cookies >= amount)
        {
            shop.BuyTool(amount);
            cookies -= amount;
            count.SetCount(cookies);
        }
    }
    
}
