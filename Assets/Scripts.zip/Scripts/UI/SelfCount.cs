using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class SelfCount : MonoBehaviour
{
    private TextMeshProUGUI TextMeshProObject;
    void Start()
    {
        TextMeshProObject = GetComponent<TextMeshProUGUI>();
    }
    public void SetCount(int count)
    {
        if(count == 1)
        {
            TextMeshProObject.text = count.ToString() + " cookie";
        }
        else
        {
            TextMeshProObject.text = count.ToString() + " cookies";
        }
    }
}
