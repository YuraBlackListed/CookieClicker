using UnityEngine;

namespace UI
{
    public class ShopPanel : MonoBehaviour
    {
    }
}
