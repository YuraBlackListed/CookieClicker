using UnityEngine;

namespace UI
{
    public class ShopButton : MonoBehaviour
    {
    }
}
