using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToolAdder : MonoBehaviour
{
    [SerializeField] private GameObject prefab;
    [SerializeField] private GameManager _manager;
    public void BuyTool(int id)
    {
        if(id == 100)
        {
            var newFinger = Instantiate(prefab, gameObject.transform.position, Quaternion.identity);
            newFinger.transform.SetParent(gameObject.transform);
            Finger tool = newFinger.GetComponentInChildren<Finger>();
            tool.manager = _manager;
        }
    }
}